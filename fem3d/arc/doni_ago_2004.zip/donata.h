c---------------------------------------------------------
c---donata.h----------------------------------------------
c----------------------------------------------------------
	real prod,cons,ddin1,ddin2
	real denit

	common /lczpar/prod,cons,ddin1,ddin2,denit

	save /lczpar/


