
c parameter for adriatic sea

	integer nkndim,neldim
	integer nlvdim
	integer mbwdim,ngrdim
	integer nrbdim,nbcdim
	integer nardim,nexdim
	integer nfldim,nfddim
	integer ipcdim,ivcdim
	integer ndldim,nfxdim
	integer nlidim

	parameter (nkndim=4000,neldim=7100)
	parameter (nlvdim=26)
	parameter (mbwdim=110,ngrdim=11)
	parameter (nrbdim=40,nbcdim=30)
	parameter (nardim=20,nexdim=50)

	parameter (nfldim=1,nfddim=1)
	parameter (ipcdim=500,ivcdim=500)
	parameter (ndldim=20,nfxdim=3000)
        parameter (nlidim=2*nkndim+neldim)


