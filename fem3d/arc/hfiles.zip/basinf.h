
c parameter file for basinf

	integer nkndim			!total number of points
	integer neldim			!total number of elements

	parameter (nkndim=12000)
	parameter (neldim=24000)

