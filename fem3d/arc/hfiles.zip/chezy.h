
	include 'param.h'

	integer nczdum
	real czdum(6,0:nardim)
	common /chezy/ nczdum,czdum

