 
c parameter for Venice Lagoon - simulations for Comune

	integer nkndim,neldim
	integer nlvdim
	integer mbwdim,ngrdim
	integer nrbdim,nbcdim
	integer nardim,nexdim
	integer nfldim,nfddim
	integer ipcdim,ivcdim
	integer ndldim,nfxdim
	integer nlidim

	parameter (nkndim=4700,neldim=8400)
	parameter (nlvdim=1)
	parameter (mbwdim=75,ngrdim=11)
	parameter (nrbdim=100,nbcdim=5)
	parameter (nardim=12,nexdim=50)

	parameter (nfldim=1,nfddim=1)
	parameter (ipcdim=500,ivcdim=500)
	parameter (ndldim=20,nfxdim=500)
        parameter (nlidim=2*nkndim+neldim)

