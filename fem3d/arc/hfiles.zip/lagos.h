
c parameter for Lago di Garda

	integer nkndim,neldim
	integer nlvdim
	integer mbwdim,ngrdim
	integer nrbdim,nbcdim
	integer nardim,nexdim
	integer nfldim,nfddim
	integer ipcdim,ivcdim
	integer ndldim,nfxdim
	integer nlidim

	parameter (nkndim=3000,neldim=6000)
	parameter (nlvdim=40)
	parameter (mbwdim=150,ngrdim=11)
	parameter (nrbdim=20,nbcdim=5)
	parameter (nardim=12,nexdim=50)

	parameter (nfldim=1,nfddim=1)
	parameter (ipcdim=500,ivcdim=500)
	parameter (ndldim=20,nfxdim=500)
        parameter (nlidim=2*nkndim+neldim)

