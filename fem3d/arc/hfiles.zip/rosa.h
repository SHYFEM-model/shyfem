
c parameter for Palude della Rosa

	integer nkndim,neldim
	integer nlvdim
	integer mbwdim,ngrdim
	integer nrbdim,nbcdim
	integer nardim,nexdim
	integer nfldim,nfddim
	integer ipcdim,ivcdim
	integer ndldim,nfxdim
	integer nlidim

	parameter (nkndim=7100,neldim=13000)
	parameter (nlvdim=12)
	parameter (mbwdim=110,ngrdim=11)
	parameter (nrbdim=25,nbcdim=10)
	parameter (nardim=10,nexdim=50)

	parameter (nfldim=1,nfddim=1)
	parameter (ipcdim=500,ivcdim=500)
	parameter (ndldim=20,nfxdim=500)
        parameter (nlidim=2*nkndim+neldim)


