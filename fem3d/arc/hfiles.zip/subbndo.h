
c routines for open boundary conditions

	integer kbcdim
	integer kopdim
	parameter ( kbcdim = 100 )	!total number of open boundary nodes
	parameter ( kopdim = 10 )	!maximum number of nodes close to OB

	integer nbndo			!total number of OB nodes
	integer ndebug			!unit number for debug messages

	integer nopnod(kbcdim)		!number of internal nodes close to OB
	integer ibcnod(kbcdim)		!number of boundary
	integer kbcnod(kbcdim)		!number of boundary node

	integer nopnodes(kopdim,kbcdim)	!nodes close to OB

	real xynorm(2,kbcdim)		!normal direction for OB node
	real wopnodes(kopdim,kbcdim)	!weights of nodes close to OB

	common /ibndoc/ nbndo, ndebug, nopnod, ibcnod, kbcnod, nopnodes
	common /rbndoc/ xynorm, wopnodes

	save /ibndoc/, /rbndoc/

