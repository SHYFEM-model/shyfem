
        integer iunit,itfold,itfnew,itfact
        common /qflxi/ iunit,itfold,itfnew,itfact

        real qsold,taold,tbold,uwold,ccold
     +			,urold,pold,eold,rold,qold
        common /qflxro/ qsold,taold,tbold,uwold,ccold
     +			,urold,pold,eold,rold,qold

        real qsnew,tanew,tbnew,uwnew,ccnew
     +			,urnew,pnew,enew,rnew,qnew
        common /qflxrn/ qsnew,tanew,tbnew,uwnew,ccnew
     +			,urnew,pnew,enew,rnew,qnew

        real qsact,taact,tbact,uwact,ccact
     +			,uract,pact,eact,ract,qact
        common /qflxra/ qsact,taact,tbact,uwact,ccact
     +			,uract,pact,eact,ract,qact

        save /qflxi/, /qflxro/, /qflxrn/, /qflxra/

