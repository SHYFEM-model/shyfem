
c parameter for Venice Lagoon

	integer nkndim,neldim
	integer nlvdim
	integer mbwdim,ngrdim
	integer nrbdim,nbcdim
	integer nardim,nexdim
	integer nfldim,nfddim
	integer ipcdim,ivcdim
	integer ndldim,nfxdim
	integer nlidim

	parameter (nkndim=3100,neldim=5400)
	parameter (nlvdim=1)
	parameter (mbwdim=60,ngrdim=10)
	parameter (nrbdim=50,nbcdim=7)
	parameter (nardim=12,nexdim=50)

	parameter (nfldim=1,nfddim=1)
	parameter (ipcdim=500,ivcdim=500)
	parameter (ndldim=20,nfxdim=500)
        parameter (nlidim=2*nkndim+neldim)

