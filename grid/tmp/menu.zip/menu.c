
/************************************************************************\
 *									*
 * menu.c - menu routines                                               *
 *									*
 * Copyright (c) 1998 by Georg Umgiesser				*
 *									*
 * Permission to use, copy, modify, and distribute this software	*
 * and its documentation for any purpose and without fee is hereby	*
 * granted, provided that the above copyright notice appear in all	*
 * copies and that both that copyright notice and this permission	*
 * notice appear in supporting documentation.				*
 *									*
 * This file is provided AS IS with no warranties of any kind.		*
 * The author shall have no liability with respect to the		*
 * infringement of copyrights, trade secrets or any patents by		*
 * this file or any part thereof.  In no event will the author		*
 * be liable for any lost revenue or profits or other special,		*
 * indirect and consequential damages.					*
 *									*
 * Comments and additions should be sent to the author:			*
 *									*
 *			Georg Umgiesser					*
 *			ISDGM/CNR					*
 *			S. Polo 1364					*
 *			30125 Venezia					*
 *			Italy						*
 *									*
 *			Tel.   : ++39-41-5216875			*
 *			Fax    : ++39-41-2602340			*
 *			E-Mail : georg@lagoon.isdgm.ve.cnr.it		*
 *									*
 * Revision History:							*
 * 28-Mar-1998: routines adopted from gridmu.c				*
 *									*
\************************************************************************/

#include <stdlib.h>

#include "assert.h"

/*
#include "grid.h"
#include "gustd.h"
*/

#include "screen.h"
#include "graph.h"
#include "mouse.h"
#include "events.h"


#define MENU_NONE		0
#define MENU_BAR		1
#define MENU_AREA		2
#define MENU_PULLDOWN		3
#define MENU_EXEC		4
#define MENU_RADIO		5
#define MENU_CHECK		6

#define INPUT_NONE		0
#define INPUT_MENU		1
#define INPUT_KEYBOARD		2
#define INPUT_PLOT		3


typedef void (*FP)( int input );


typedef struct menu_entry_tag {
	char		*name;			/* name of menu item */
	int		 type;			/* type of menu item */
	FP		 function;		/* fuction called on click */
	int		 nsubs;			/* number of submenu entries */
	IRect		 position;		/* position of menu on screen */
	struct menu_entry_tag	*submenu;	/* submenus if pulldown */
	struct menu_entry_tag	*next;		/* next sibling */
} Menu_entry;


/***********************************************************************/


static Menu_entry *MainMenu = 0;	/* main menu (menu bar/area) */

static IRect WinDim = {0,0,0,0};	/* actual dimension of total window */
static IRect MenDim = {0,0,0,0};	/* actual dimension of menu bar/area */

static int Permanent=FALSE; /* false for drag-down menu, true for pop-up */

static int FgMainMenuCol = Black;	/* colors for main menu */
static int BgMainMenuCol = Green;
static int BlMainMenuCol = White;
static int BdMainMenuCol = Grey;

static int FgButtonCol = Black;		/* colors for buttons in main menu */
static int BgButtonCol = Green;
static int BlButtonCol = White;		/* light boundary for shading */
static int BdButtonCol = Grey;		/* dark boundary for shading */

static int FgPulldownCol = Black;	/* colors for pulldown menu */
static int BgPulldownCol = Green;
static int BdPulldownCol = White;


/********************** prototypes *************************/


void DisplayMenuBar( Menu_entry *main );
void DisplayMenuArea( Menu_entry *main );

static void FindMaxTextDimension( Menu_entry *menu 
			, int *width , int *height , int *totwidth );


/********************** static routines *************************/


static Menu_entry *MakeMenuItem( char *name , int type )

{
	Menu_entry *new;

	new = (Menu_entry *) malloc( sizeof(Menu_entry) );
	if( !new ) Error("Cannot make menu entry");

	new->name = (char *) malloc( strlen(name) + 1 );
	if( !new->name ) Error("Cannot make name of menu entry");
	strcpy(new->name,name);

	new->type = type;
	new->function = NULL;
	new->nsubs = 0;
	new->submenu = NULL;
	new->next = NULL;

	return new;
}

static void DeleteMenus( Menu_entry *menu )

/* deletes all submenus */

{
	if( menu->submenu )
	    DeleteMenus( menu->submenu );

	if( menu->name )
	    free( menu->name );

	if( menu->next )
	    DeleteMenus( menu->next );

	free( menu );
}


/********************** public routines *************************/


void RegisterMainMenu( Menu_entry *main )

{
	ASSERT( main != NULL );

	if( MainMenu )
	    Error("Main menu already registered");

	if( main->type != MENU_BAR && main->type != MENU_AREA )
	    Error("Trying to register an erroneous menu");

	MainMenu = main;
}

void DeleteMainMenu( void )

{
	DeleteMenus( MainMenu );
}

Menu_entry *MakeMenuBar( void )

{
	Menu_entry *new;

	new = MakeMenuItem("Menu Bar",MENU_BAR);
	RegisterMainMenu(new);

	return new;
}

Menu_entry *MakeMenuArea( void )

{
	Menu_entry *new;

	new = MakeMenuItem("Menu Area",MENU_AREA);
	RegisterMainMenu(new);

	return new;
}

Menu_entry *MakePulldownMenu( char *name )

{
	return MakeMenuItem(name,MENU_PULLDOWN);
}

Menu_entry *MakeExecMenu( char *name , FP function )

{
	Menu_entry *new;

	new = MakeMenuItem(name,MENU_EXEC);
	new->function = function;

	return new;
}

void AddMenuItem( Menu_entry *parent , Menu_entry *submenu )

{
	Menu_entry *item;

	ASSERT( parent );
	ASSERT( 
		parent->type == MENU_PULLDOWN ||
		parent->type == MENU_BAR ||
		parent->type == MENU_AREA 
	      );

	item = parent->submenu;

	if( item == NULL ) {
	  parent->submenu = submenu;
	} else {
	  while( item->next )
	     item = item->next;
	  item->next = submenu;
	}

	parent->nsubs++;
}

void SetMenuDimension( IRect window , IRect menu )

/* sets dimensions of total window and menu bar/area */

{
	WinDim = window;
	MenDim = menu;
}


void DisplayMainMenu( void )

{
	if( !MainMenu )
	    Error("No main menu registered for display");

	if( MainMenu->type == MENU_BAR ) {
	    DisplayMenuBar( MainMenu );
	} else if( MainMenu->type == MENU_AREA ) {
	    DisplayMenuArea( MainMenu );
	} else {
	    Error("Main menu not of expected type");
	}
}

void DisplayMenuBar( Menu_entry *main )

{
	Error("Not yet ready for menu bar");
}

void RegisterMenuAreaDimensions( Menu_entry *main )

/* this has to be done only if MenDim changes -> check for it */

{
	int menuwidth, menuheight;
	int menuitems;
	int maxwidth, maxheight, totwidth;
	int buttonwidth, buttonheight;
	int xmargin, ymargin;
	int onespace;
	int x,y,dx,dy;
	Menu_entry *item;

	menuwidth  = MenDim.xmax - MenDim.xmin + 1;
	menuheight = MenDim.ymax - MenDim.ymin + 1;
	menuitems  = main->nsubs;

	ASSERT( menuwidth > 1 );
	ASSERT( menuheight > 1 );
	ASSERT( menuitems > 0 );

	FindMaxTextDimension(MainMenu,&maxwidth,&maxheight,&totwidth);

	/* find good width */

	if( 1.1 * maxwidth < menuwidth ) {	/* enough space */
	    buttonwidth = 1.1 * maxwidth;
	} else if( maxwidth < menuwidth ) {	/* space is tight */
	    buttonwidth = maxwidth + (menuwidth-maxwidth) / 2;
	} else {				/* space too low */
	    buttonwidth = menuwidth;
	}
	xmargin = menuwidth - buttonwidth;

	/* find acceptable height */

	if( menuitems * 3 * maxheight < menuheight ) {	/* ok */
	    buttonheight = 2 * maxheight;
	    ymargin = maxheight;
	} else if( menuitems * maxheight < menuheight ) { /* space tight */
	    onespace = menuheight / menuitems;
	    ymargin = (onespace - maxheight) / 2;
	    buttonheight = maxheight + ymargin;
	} else {					/* space too low */
	    buttonheight = menuheight / menuitems;
	    ymargin = 0;
	}

	/* register dimensions of buttons */

	x = MenDim.xmin + xmargin/2;
	y = MenDim.ymax - ymargin/2;
	dx = buttonwidth;
	dy = buttonheight;

	item = main->submenu;
	while( item ) {
	    (void)  ToIRect( &(item->position) , x , y-dy , x+dx , y );
	    y -= dy;
	    item = item->next;
	}
}

void PlotMenuArea( Menu_entry *main )

{
	IRect *irect;
	Menu_entry *item;
	int x0,y0;

	MouseHide();

	/* fill menu area */

	SViewport( &MenDim );

	SFillRect( &MenDim , BgMainMenuCol );
	SShadeRect( &MenDim , BlMainMenuCol , BdMainMenuCol );

	STextBackground( BgButtonCol );

	/* plot single buttons */

	item = main->submenu;
	while( item ) {
	    irect = &(item->position);

	    SFillRect( irect , BgButtonCol );
	    SShadeRect( irect , BlButtonCol , BdButtonCol );

	    QNewPen(FgButtonCol);
	    SCenterText( irect , item->name , &x0 , &y0 );
	    SText( x0 , y0 , item->name );

	    item = item->next;
	}

	/* reset normal state */

	STextBackground( Black );

	MouseShow();
}

void DisplayMenuArea( Menu_entry *main )

{
	RegisterMenuAreaDimensions( main );
	PlotMenuArea( main );
}

/************************************************************************/

int InButton( IRect *irect , int x , int y )

{
	if( x < irect->xmin || x > irect->xmax ) return FALSE;
	if( y < irect->ymin || y > irect->ymax ) return FALSE;

	return TRUE;
}

Menu_entry *FindMenuChoice( Menu_entry *menu , int x , int y )

{
	Menu_entry *item;

	item = menu->submenu;
	while( item ) {
	    if( InButton( &(item->position) , x , y ) )
		return item;
	    item = item->next;
	}
	return NULL;
}

void ProcessMenuInput( int x , int y )

{
	if( x < MenDim.xmin || x > MenDim.xmax ) return;
	if( y < MenDim.ymin || y > MenDim.ymax ) return;
}



static void FindMaxTextDimension( Menu_entry *menu 
			, int *width , int *height , int *totwidth )

{
    int totw=0;
    int maxw=0;
    int maxh=0;
    int w,h;

    menu = menu->submenu;
    while( menu ) {
        QTextDimensionsI(menu->name,&w,&h);
	totw += w;
        maxw = MAX(w,maxw);
        maxh = MAX(h,maxh);
        menu = menu->next;
    }

    *totwidth=totw;
    *width=maxw;
    *height=maxh;
}






#ifdef GGUUTT


/***************** old code *********************/





static Popup_item_type *MpHead=NULL;


static int FgCol;
static int BgCol;
static int BdCol;


static void FindPopupDimension( Popup_item_type *mp , int *nentry
				, int *w , int *h );
static void FindPopupCoordinates( int width , int height
				, int *xc , int *yc );
static char **GetPopupText( Popup_item_type *mp , int nmenus );
static Button_type FindPopupEntry( Popup_item_type *mp , int i );


Button_type CallPopup( Button_type button , int horiz , int verti )

{
    Popup_item_type *mpaux;

    mpaux = MpHead->submenu;
    while( mpaux ) {
        if( mpaux->id == button ) break;
        mpaux = mpaux->next;
    }

    if( mpaux ) {
        return PopupMenu( mpaux , horiz , verti );
    } else {
        return NONE;
    }
}



void CheckEventInput( QEvent event );

Button_type PopupMenu( Popup_item_type *mp , int x , int y )

{
    int width,height,totheight;
    int nmenus=0;

    float x0,y0,dx,dy;

    int i,iold;
    int loop,changed,pressed;
    int mhoriz,mverti;
    char **texts;
    void *pixmap;

    QEvent event;

    FindPopupDimension(mp,&nmenus,&width,&height);

    width = (width*5)/4;
    height = (height*9)/4;
    totheight = height*nmenus;

    FindPopupCoordinates(width,totheight,&x,&y);

    pixmap=QSavePixels(x,y,width,totheight);

    QViewport(x,y,x+width-1,y+totheight-1);
    QWindow(0.,0.,(float)width,(float)totheight);

    pressed=TRUE;
    if( Permanent ) { /* wait till button is released */
      for(;;) {
	QNextEvent( &event );
	if( event.type == QButtonPress && event.button.press == QButtonUp )
		break;
      }
      pressed=FALSE;
    }

    dx=width;
    dy=height;
    x0=0.;
    y0=totheight-dy;

    texts = GetPopupText(mp,nmenus);

    for( i=0 ; i<nmenus ; i++,y0-=dy )
	PlotMenuItem(texts[i],x0,y0,dx,dy,FgCol,BgCol,BdCol);

    QAddEvent( QPointerMoveMask );

    iold = -1;
    do {
	QNextEvent( &event );
/*	CheckEventInput( event ); */
	if( event.type == QButtonPress ) {
	  if( event.button.button == QButtonLeft ) {
	    pressed = (event.button.press==QButtonDown) ? TRUE : FALSE;
	  }
	  mhoriz=event.button.x;
	  mverti=event.button.y;
	} else if( event.type == QPointerMove ) {
	  mhoriz=event.button.x;
	  mverti=event.button.y;
	} else {
	  /* process other events !!!! */
	  mhoriz = -1;
	  mverti = -1;
	}

	i = -1;
	if(mhoriz>=x && mhoriz<x+width) {
	    if(mverti>=y && mverti<y+totheight) {
		i=(mverti-y)/height;
	    }
	}

	if( i != iold ) {
	    if( iold != -1 ) {
	      y0=totheight-(iold+1)*dy;
	      PlotMenuItem(texts[iold],x0,y0,dx,dy,FgCol,BgCol,BdCol);
	    }
	    if( i != -1 ) {
	      y0=totheight-(i+1)*dy;
	      PlotMenuItem(texts[i],x0,y0,dx,dy,BgCol,FgCol,BdCol);
	    }
	    iold=i;
	    changed=TRUE;
	} else {
	    changed=FALSE;
	}

	if( Permanent ) {
	    loop = ( !pressed || changed );
	} else {
	    loop = pressed;
	    if( !loop )
		iold = changed ? -1 : iold;
	}

    } while( loop );

    QDeleteEvent( QPointerMoveMask );

    if( pixmap )
        QRestorePixels( x , y , pixmap );
    else
	RedrawAll();

    free(texts);
    QNewPen(PlotCol);

    return FindPopupEntry(mp,iold);
}

static void FindPopupDimension( Popup_item_type *mp , int *nentry
				, int *w , int *h )

{
    int maxwidth=0;
    int maxheight=0;
    int width,height;
    int n=0;

    mp = mp->submenu;
    while( mp ) {
        QTextDimensionsI(mp->text,&width,&height);
        maxwidth = width>maxwidth ? width : maxwidth;
        maxheight = height>maxheight ? height : maxheight;
        n++;
        mp = mp->next;
    }
    *nentry=n;
    *w=maxwidth;
    *h=maxheight;
}

static void FindPopupCoordinates( int width , int height
				, int *xc , int *yc )

{
    /* height is total height of menu */

    int x,y;
    int xminpix=XTMin;
    int yminpix=YTMin;
    int xmaxpix=XTMax;
    int ymaxpix=YTMax;

    x = *xc;
    y = *yc;

    x = x-width+1 - 5;
    if( x < xminpix ) {
	x = x+width-1 + 10;
	if( x+width-1 > xmaxpix ) {
	    if( width > xmaxpix-xminpix+1 )
                Error("No space for submenu");
            else
                x = ((xmaxpix-xminpix+1)-width)/2;
        }
    }

    y += 5;
    if( y+height-1 > ymaxpix ) {
        y = y-height+1 - 10;
        if( y < yminpix ) {
            if( height > ymaxpix-yminpix+1 )
                Error("No space for submenu");
            else
                y = ((ymaxpix-yminpix+1)-height)/2;
        }
    }

    *xc = x;
    *yc = y;
}

static char **GetPopupText( Popup_item_type *mp , int nmenus )

{
    char **texts;
    int i=0;

    texts = (char **) malloc( nmenus * sizeof(char *) );
    if( texts == NULL ) Error("Cannot allocate submenu");

    mp = mp->submenu;
    while( mp ) {
	texts[i++] = mp->text;
	mp = mp->next;
    }

    return texts;
}

static Button_type FindPopupEntry( Popup_item_type *mp , int i )

{
    if( i < 0 )
	return NONE;

    mp = mp->submenu;
    while( i-- && mp )
	mp = mp->next;

    if( mp )
	return mp->id;
    else
	return NONE;
}

void PlotMenuItem( char *s , float x0 , float y0 , float dx , float dy
                    , int fgcol , int bgcol , int bdcol )

{
    float width,height;

	MouseHide();

    QTextDimensions(s,&width,&height);

    QRectFill(x0,y0,x0+dx,y0+dy,bgcol);
    QTextBackground(bgcol);

    QNewPen(bdcol);
    QMove( x0 , y0 );
    QPlot( x0+dx , y0 );
    QPlot( x0+dx , y0+dy );
    QPlot( x0 , y0+dy );
    QPlot( x0 , y0 );

    QNewPen(fgcol);
    QText( x0 + (dx-width)/2. , y0 + (dy-height)/2. , s );
    QTextBackground(Black);

	MouseShow();
}



/*******************************************************************/


Button_type FindButtonByCoord( float x , float y )

{
	Button_list_type *bp;

	for( bp=BLP ; bp!=NULL ; bp=bp->next )
		if( bp->minmax.low.x <= x && bp->minmax.high.x >= x )
			if( bp->minmax.low.y <= y && bp->minmax.high.y >= y )
				return bp->button;

	return NONE;
}



#endif
