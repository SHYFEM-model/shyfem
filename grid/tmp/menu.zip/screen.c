
/************************************************************************\ 
 *									*
 * screen.c - screen manipulation routines				*
 *									*
 * Copyright (c) 1998 by Georg Umgiesser				*
 *									*
 * Permission to use, copy, modify, and distribute this software	*
 * and its documentation for any purpose and without fee is hereby	*
 * granted, provided that the above copyright notice appear in all	*
 * copies and that both that copyright notice and this permission	*
 * notice appear in supporting documentation.				*
 *									*
 * This file is provided AS IS with no warranties of any kind.		*
 * The author shall have no liability with respect to the		*
 * infringement of copyrights, trade secrets or any patents by		*
 * this file or any part thereof.  In no event will the author		*
 * be liable for any lost revenue or profits or other special,		*
 * indirect and consequential damages.					*
 *									*
 * Comments and additions should be sent to the author:			*
 *									*
 *			Georg Umgiesser					*
 *			ISDGM/CNR					*
 *			S. Polo 1364					*
 *			30125 Venezia					*
 *			Italy						*
 *									*
 *			Tel.   : ++39-41-5216875			*
 *			Fax    : ++39-41-2602340			*
 *			E-Mail : georg@lagoon.isdgm.ve.cnr.it		*
 *									*
 * Revision History:							*
 * 28-Mar-1998: routines adapted from graph.c                           *
 *									*
\************************************************************************/


#include <stdlib.h>

#include "graph.h"


typedef struct {
	int xmin;
	int ymin;
	int xmax;
	int ymax;
} IRect;


IRect *ToIRect( IRect *irect , int xmin , int ymin , int xmax , int ymax )

{
	if( !irect ) {
	    irect = (IRect *) malloc( sizeof(IRect) );
	    if( !irect )
		Error("Cannot allocate IRect");
	}

	irect->xmin = xmin;
	irect->ymin = ymin;
	irect->xmax = xmax;
	irect->ymax = ymax;

	return irect;
}

void SViewport( IRect *view )

{
	int xmin = view->xmin;
	int ymin = view->ymin;
	int xmax = view->xmax;
	int ymax = view->ymax;

	QViewport( xmin , ymin , xmax , ymax );
	QWindow( (float) xmin , (float) ymin , (float) xmax , (float) ymax );
}

void SMove( int x , int y )

{
	QMove( (float) x , (float) y );
}

void SPlot( int x , int y )

{
	QPlot( (float) x , (float) y );
}

void SLine( int x1 , int y1 , int x2 , int y2 )

{
	QLine( (float) x1 , (float) y1 , (float) x2 , (float) y2 );
}

void SPlotRect( IRect *irect )

{
	QMove( (float) irect->xmin , (float) irect->ymin );
	QPlot( (float) irect->xmin , (float) irect->ymax );
	QPlot( (float) irect->xmax , (float) irect->ymax );
	QPlot( (float) irect->xmax , (float) irect->ymin );
	QPlot( (float) irect->xmin , (float) irect->ymin );
}


void SFillRect( IRect *irect , int color )

{
	float xmin = irect->xmin;
	float ymin = irect->ymin;
	float xmax = irect->xmax;
	float ymax = irect->ymax;

	QRectFill(xmin,ymin,xmax,ymax,color);
}

void SShadeRect( IRect *irect , int darkcolor , int lightcolor )

{
	float xmin = irect->xmin;
	float ymin = irect->ymin;
	float xmax = irect->xmax;
	float ymax = irect->ymax;

	/* first pass */

	QNewPen(darkcolor);
	QLine( xmin , ymin , xmin , ymax );
	QLine( xmin , ymax , xmax , ymax );
	QNewPen(lightcolor);
	QLine( xmax , ymax , xmax , ymin );
	QLine( xmax , ymin , xmin , ymin );

	/* second pass -> thicken line */

	xmin += 1.; ymin += 1.;
	xmax -= 1.; ymax -= 1.;

	QNewPen(darkcolor);
	QLine( xmin , ymin , xmin , ymax );
	QLine( xmin , ymax , xmax , ymax );
	QNewPen(lightcolor);
	QLine( xmax , ymax , xmax , ymin );
	QLine( xmax , ymin , xmin , ymin );
}

/**************************************************************************/

void SText( int x , int y , char *s )

{
	QText( (float) x , (float) y , s );
}

void STextSize( int size )

{
	QTextSize( size );
}

void STextBackground( int color )

{
	QTextBackground( color );
}

void STextDimensions( char *s , int *width , int *height )

{
	QTextDimensionsI( s , width , height );
}

void SCenterText( IRect *irect , char *s , int *x0 , int *y0 )

{
	int w,h;

	STextDimensions( s , &w , &h );

	*x0 = ( irect->xmin + irect->xmax - w ) / 2 ;
	*y0 = ( irect->ymin + irect->ymax - h ) / 2 ;
}

/**************************************************************************/

